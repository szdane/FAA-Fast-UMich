infeasible_regions_fake_east -> weather shifted east

infeasible_regions_fake_west -> weather shifted west

infeasible_regions_fake_south -> weather shifted south

infeasible_regions_static_lowres -> tiny weather areas removed

infeasible_regions_fake_highfreq -> weather shifted north at very high frequency intervals (10 seconds)